%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gina Szajnbok Harari (UPM) 72008075@mackenzista.com.br
% Baseado em:  Joseph Harari (IOUSP) joharari@usp.br
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GNU Octave(R) - Version 5.2.0
% Module : disp_part_progr_exp1100so_plot_gsh.m 
% Programa para plotar trajetorias de particulas soltas no litoral de S�o Paulo
% atrav�s de vetores progressivos no tempo, utilizando dados de correntes 
% de modelo numerico hidrodinamico.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adapta��es do programa original (USP):
% Os dados foram restritos a dez dias
% Foram selecionados:
% - ponto de soltura #1100 (o modelo original tem v�rios pontos de soltura)
% - Alem da plotagem total dos 100 pontos, adaptamos o programa para a 
%   plotagem das trajetorias de **n particulas especificas** 
%   requisitadas na execucao
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
% limpa as vari�veis e cria o diret�rio output
clear all; close all; clc
mkdir output

% seta lat,lon min e max que ser� a �rea estudada
lonmin = -46.7952;
lonmax = -44.3319;
latmin = -24.8317;
latmax = -23.3299;

% RT � o Raio m�dio da Terra
RT = 6378135.59;

% seleciona o limite de 3.000.000 como deslocament m�ximo das part�culas
% inicializa o numero de particula selecionadas
dist_lim = 3e6
partsel = 0;

% l� contorno terrestre 
% inicializa as vari�veis lonterra, latterra com o contorno terrestre
% limpa a vari�vel auxuliar data
load input/coastline.mat
lonterra = data.X;
latterra = data.Y;
clear data

% arquivo das posicoes iniciais das particulas (em lat, lon)
% formato: col 1-num.part, col 2-lon, col 3-lat

% carrega o arquivo na matriz x
load input/pos_part_exp1100.dat
x = pos_part_exp1100;

% inicializa nupart com o valor do numero de linhas da matriz x( = part�culas)
nupart = size(x,1);

% inicializa lonp com um vetor longitude
lonp = x(:,2);

% inicializa latp com um vetor latitude
latp = x(:,3);

% inicializa lonpart com um vetor longitude
% inicializa latpart com um vetor latitude
lonpart(:,1) = lonp;
latpart(:,1) = latp;

% Loop para todos os arquivos de cada particula

for npart = 1:nupart
arquivo = ['output/traj_part_progr_exp1100_' num2str(npart) '.out'];
eval(['load ' arquivo])
eval(['xxx=traj_part_progr_exp1100_' num2str(npart) ';'])

% nutime = 10 dias com espacamento de 15 minutos = 240 horas 957 medidas de long e lat
nutime = size(xxx,1);

% arquivo das Trajetorias das particulas (em lat, lon)
% formato: col 11-lon, col 12-lat
lonpart(npart,1:nutime) = xxx(:,11);
latpart(npart,1:nutime) = xxx(:,12);

% calcular distancia entre posicao inicial e final de cada particula
latmp = (latpart(npart,nutime)+latpart(npart,1))/2;
disty = (latpart(npart,nutime)-latpart(npart,1))*RT;
distx = (lonpart(npart,nutime)-lonpart(npart,1))*cos(latmp)*RT;
distp(npart) = sqrt(distx^2+disty^2);

% inicializa o sinalizador de distancia 
kdistlim = 0;
for ntime = 1:nutime
    if(distp(npart) > dist_lim) kdistlim = 1; end
end

% se particula superou a distancia, limite seleciona a particula
if (kdistlim == 1) 
    partsel = partsel+1;
    partselec(partsel) = npart;
    distsel(partsel) = distp(npart);
end

end

numero_particulas_afastadas = partsel
particulas_afastadas = partselec(1:end)
distancias = distsel

% plotagem das trajetorias de **todas** as particulas (em lat, lon)
figure
plot(lonterra,latterra,'k')
axis equal
axis([lonmin lonmax latmin latmax])
hold on
for npart = 1:nupart
plot(lonpart(npart,1),latpart(npart,1),'*b','LineWidth',1.5)
plot(lonpart(npart,1:nutime),latpart(npart,1:nutime),'r','LineWidth',1.5)
end

text(-46.5,-23.8,'SANTOS')
text(-46.2,-23.7,'BERTIOGA')
text(-45.5,-23.45,'UBATUBA')
text(-46.75,-23.5,'ESTADO DE SAO PAULO')
xlabel('LONGITUDE (graus)')
ylabel('LATITUE (graus)')
title('TRAJETORIAS DAS PARTICULAS (VETOR PROGRESSIVO)')
print -djpeg output/traj_part_progr_latlon_exp1100gsh

kfig = 1;

% plotagem das trajetorias de **n particulas especificas** requisitadas na execucao

numselpart = input('Escolher numero de particulas selecionadas, entre 1 e 100: ');    

for nselpart = 1:numselpart
kfig = kfig + 1;

nselpart = input('Indice da particula selecionada, entre 1 e 100: ');    

figure (kfig)
plot(lonterra,latterra,'k')
axis equal
axis([lonmin lonmax latmin latmax])
hold on

plot(lonpart(nselpart,1),latpart(nselpart,1),'*b','LineWidth',1.5)

title(['Particula ' num2str(nselpart)])

for ntime = 1:nutime
plot(lonpart(nselpart,1:ntime),latpart(nselpart,1:ntime),'r','LineWidth',1.5)
pause(0.005)
end

text(-46.5,-23.8,'SANTOS')
text(-46.2,-23.7,'BERTIOGA')
text(-45.5,-23.45,'UBATUBA')
text(-46.75,-23.5,'ESTADO DE SAO PAULO')
xlabel('LONGITUDE (graus)')
ylabel('LATITUE (graus)')
eval(['print -djpeg output/traj_part_progr_latlon_exp1100gsh_part' num2str(nselpart)]);

end


